// Create a new date instance dynamically with JS
let d = new Date();
let date = d.getMonth()+1+'_'+ d.getDate()+'_'+ d.getFullYear();

//Async fetch w/web API's 
let baseUrl = 'https://api.openweathermap.org/data/2.5/weather?zip=';
const key = ',&appid=b05d3ddb8c421ec15ba643a4c35c804b&units=metric';

//adding EVENT LISTENER to the buttton GENERATE
document.getElementById('generate').addEventListener('click', action)


//the LISTENER's function
function action(){
    //getting elements' values and storing them into constants
    let userInput = document.getElementById("zip").value; 
    let feeling = document.querySelector("#feelings").value;

    getData(baseUrl, userInput, key) //impelementing the Request

    //After impelemnting the request,
    .then(function(da){

       //POST/ send the data to the server's route defined as the first argument in the function.
       postData("/addData", { date: date, temp:da.main.temp, feelings: feeling})

       //Running the update-dynamically function
       update("/all")
    });
  
}

// Get/Request data from API's server.
const getData = async (baseUrl, zip, ky)=>{
    const response = await fetch(baseUrl+zip+ky);
    //console.log(response);


    try {
        const responseJson = await response.json(); // turn data into an object/json code.
        if (responseJson.message === "city not found" || responseJson.cod === "404" || responseJson.message === "invalid zip code"){
           alert("Invalid Zipcode");
        }
    console.log(responseJson)
        return responseJson;
    } catch (error) {
        console.log('error: ', error);
    }

};


const postData= async(url="", responseJson={})=>{
    const response = await fetch(url, {
      method: "POST",
      credentials: "same-origin",
      headers: {"content-type":"application/json"},
      body: JSON.stringify(responseJson)
    });

    try {
        const responseJson = await response.json();
        return responseJson;
    } catch (error) {
        console.log("error: ", error);
    }
};

//Updating the UI dynamically
const update = async (url)=>{
     const response= await fetch(url);
     
    try {
        const resJson = await response.json();
        //giving the selected elements values of the data returned
        document.getElementById('date').innerHTML= "Date: "+resJson.date;
        document.getElementById('temp').innerHTML= "Temp: "+resJson.temp+"&deg;C";
        document.getElementById('content').innerHTML= "Feel: " +resJson.content;
        
    } catch (error) {
        console.log("error: ", error)
    }
}