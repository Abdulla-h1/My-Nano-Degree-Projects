# Landing Page Project

## Table of Contents

* [Instructions](#instructions)

## Instructions

The starter project has some HTML and CSS styling to display a static version of the Landing Page project. You'll need to convert this project from a static project to an interactive one. This will require modifying the HTML and CSS files, but primarily the JavaScript file.

. HTML content has been edited by using primarly JavaScript.

. Dynamically built-in navigation menu has been added: 
- created as many `<li>` element as the number of sections inserted.  
- appended `<a>` element, its count is based on `<li>` elements count and, so, sections count, to the `<li>` element.
- set the `href` attribute the same exactly as `<section>` element id<sub>s</sub> so that it's linked to them.
- appended the newly created `<li>` element to the `<ul>` element for an unordered list.
- setting the `<a>` element appended to the `<li>` referring to each `<section>` element by its id, allowed scrolling
down to each section when clicking on the anchor link. 

. Created the button that would allow to scroll right to the top of the landing-page:
- created new `<button>` element and inserted it to the HTML content before the `<footer>` element.
- named the `<button>` element a descriptive name and gave it attractive style.
- styled the `<button>` element position as fixed so that it could be seen in every section on the window.
- added window.scrollTo property to the `<button>` to make it interactive and enable its functionality. 

. Add class 'active' to section when near top of viewport
- Added scroll event to the window
- if a sections[i] is in the view port, it will take the class active.
- if a sections[i] is not in the view, it will not take the class active.  

.once scrolling down, when the Section 1 is in the view port, the navbar disappears.  
- stroing the navbar in a variable so it can be used effeciently widly
- the Section 1 is in the view port, the navbar disappears.



To get started, open `js/app.js` and uystart building out the app's functionality

For specific, detailed instructions, look at the project instructions in the Udacity Classroom.
