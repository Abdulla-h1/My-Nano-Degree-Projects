/**
 *
 * Manipulating the DOM exercise.
 * Exercise programmatically builds navigation,
 * scrolls to anchors from navigation,
 * and highlights section in viewport upon scrolling.
 *
 * Dependencies: None
 *
 * JS Version: ES2015/ES6
 *
 * JS Standard: ESlint
 *
*/

//building the dynamically built navigation as an unordered list.

//setting global variables

const sections = document.querySelectorAll('section');   //storing the navigation unordered list in a var
const newUl = document.querySelector('ul');       //storing the sections for looping over them

/**
 * End Global Variables
 * Start Helper Functions
 *
*/

// build the nav

//creating anchor link for each new section dynamically.
const buildingNavBar = function(){
for(let i = 0; i < sections.length;i++){
    
    let newLi= document.createElement('li');    //creating lists that will be appended to the navigation menu
    let newLink = document.createElement('a');     //creating the nav link element

    let secId= sections[i].getAttribute('id');
    
    let secData= sections[i].getAttribute('data-nav');

    //setting the sections' nav link
    
    newLink.setAttribute('href', secId);
    
    newLink.textContent = secData;   //creating content fot the anchor 
   
    
    newLi.appendChild(newLink); newUl.appendChild(newLi);    //creating the Unordered list content/nodes
   
    newLink.addEventListener('click', function(e){
    e.preventDefault(); 
    sections[i].scrollIntoView({behavior: 'smooth'})});

    
// Add class 'active' to section when near top of viewport

//Add scroll event to the window
    window.addEventListener('scroll', function(){ 
     //if a sections[i] is in the view port, it will take the class active.   
        if(sections[i].getBoundingClientRect().y < 488 && sections[i].getBoundingClientRect().y > -127){
            
            sections[i].classList.add('your-active-class');
        }
     //if a sections[i] is not in the view, it will not take the class active.  
        else {sections[i].classList.remove('your-active-class');};
        
     //once scrolling down, when the Section 1 is in the view port, the navbar disappears.  
        const navBlockNone = document.querySelector('.navbar__menu'); //stroing the navbar in a variable so it can be used effeciently widly
        if(sections[0].getBoundingClientRect().y < 100 ){  //the Section 1 is in the view port, 
            navBlockNone.style.cssText= 'display: none';   //the navbar disappears.
        }
        else{navBlockNone.style.cssText= 'display: block'}; //else, it appears.
        
    });


 };

};

buildingNavBar(); 





// Scroll to anchor ID using scrollTO event
const newFooter= document.querySelector('footer');
let scrollToTopBtn= document.createElement('button'); //creating the button for scrolling
scrollToTopBtn.textContent = 'Top';   //naming the button

//styling the button
scrollToTopBtn.style.cssText = 'position: fixed ;width: 40px; height: 50px; right: 12px; bottom: 12px ;border-radius: 40px; background: green; cursor: pointer; color: white; outline: none; border: none';

//inserting the button to the HTML file before the <footer> in it
newFooter.insertAdjacentElement('beforebegin', scrollToTopBtn);

//creating event handler for the scroll to top button
scrollToTopBtn.addEventListener('click', function(){
    window.scrollTo({
        top:0,
        left:0,
        behavior: 'smooth'
    });
});


